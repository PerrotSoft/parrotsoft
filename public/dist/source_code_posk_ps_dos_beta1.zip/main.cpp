// psdos.cpp — командная оболочка PS DOS поверх ядра ParrotOS (POSK).
//
// Не ядро. Это userland-приложение (.pex), запускается как start.pex
// (или другим именем — см. Minimal.dsc / build-скрипт) поверх уже
// загруженного ядра третьей беты.
//
// Синтаксис гибридный DOS+Linux: каждой команде соответствует набор
// алиасов (dir/ls, cd, type/cat, del/rm, copy/cp, move/mv, md/mkdir,
// rd/rmdir, cls/clear, ver, help, exit). Регистр не важен, как в MS-DOS.
//
// Режим по умолчанию — текстовый (Console:: / INT 0x21). Флаг режима
// (текст/графика) ожидается в ArgContext процесса как CHAR16*-строка
// командной строки запуска — см. блок ParseLaunchArgs ниже.
// ЭТО ПРЕДПОЛОЖЕНИЕ: в ядре пока нет задокументированного формата
// ArgContext для .pex, поэтому распарсено защитно (если формат другой —
// просто не найдёт флаг "-gfx" и останется в текстовом режиме).

#include "ParrotOS_API.hpp"
#include "str16.h"

using namespace ParrotOS;
using namespace ps;

// ---------------------------------------------------------------------
// ФИКС БАГА SDK: FileSystem::ChangeDir в ParrotOS_API.hpp вызывает
// "int $0x23" РАНЬШЕ, чем указатель на путь кладётся в RCX (сравните с
// любой другой функцией в том же namespace — CreateDir, DeleteFile,
// ListDir и т.д. — там RCX выставляется ДО interrupt). Из-за этого
// ядро на момент обработки прерывания читает из RCX случайный мусор,
// а не реальный путь — ChangeDir либо не работает, либо "работает"
// случайно, если в RCX по счастливой случайности осталось что-то
// похожее на указатель на строку. Обходим здесь правильным порядком
// инструкций, не трогая сам SDK-файл. Тот же баг нужно поправить и в
// ParrotOS_API.hpp — иначе он ударит по любому другому приложению,
// которое вызовет FileSystem::ChangeDir напрямую.
static uint64_t FixedChangeDir(const CHAR16* path) {
    uint64_t r;
    asm volatile (
        "movq $0x07, %%rax\n\t"
        "movq %1, %%rcx\n\t"
        "int $0x23\n\t"
        "movq %%rax, %0"
        : "=r"(r)
        : "r"(path)
        : "rax", "rcx"
    );
    return r;
}

// ---------------------------------------------------------------------
// Константы и глобальное состояние оболочки
// ---------------------------------------------------------------------

static constexpr int kMaxLine   = 256;
static constexpr int kMaxArgs   = 16;
static constexpr uint64_t kAttrNormal = 0x07; // светло-серый на чёрном (аналог DOS 07h)
static constexpr uint64_t kAttrPrompt = 0x0A; // ярко-зелёный, как приглашение bash
static constexpr uint64_t kAttrError  = 0x0C; // ярко-красный

static bool gGfxMode = false; // зарезервировано под графический режим (см. TODO ниже)

// ---------------------------------------------------------------------
// ИСПРАВЛЕННЫЕ коды спецклавиш. Константы Keys::Up/Down/Right/Left/Esc
// из ParrotOS_API.hpp (0x0100/0x0200/.../0x1700) НЕ совпадают с тем,
// что реально возвращает Keyboard::GetKey() — подтверждено скриншотом
// debug-строки в fm: реальный код Down = 0xFF02. Сверено со старыми
// 32-битными SCAN_* макросами в ParrotOS_API.h (SCAN_UP=0x01FF0000,
// SCAN_DOWN=0x02FF0000, SCAN_RIGHT=0x03FF0000, SCAN_LEFT=0x04FF0000,
// SCAN_ESC=0x17FF0000) — паттерн: реальный 16-битный код = 0xFF00 | id,
// где id — старший байт старой 32-битной константы. Down (id=0x02)
// подтверждён напрямую (0xFF02); Up/Right/Left/Esc — та же схема по
// аналогии, но эмпирически проверен только Down. Если Esc/Up окажутся
// другими — debug-строка в fm тут же это покажет.
static constexpr CHAR16 kKeyUp    = 0xFF01;
static constexpr CHAR16 kKeyDown  = 0xFF02;
static constexpr CHAR16 kKeyRight = 0xFF03;
static constexpr CHAR16 kKeyLeft  = 0xFF04;
static constexpr CHAR16 kKeyEsc   = 0xFF17;

// ---------------------------------------------------------------------
// Вывод — тонкая обёртка над Console::*, чтобы позже можно было
// подменить на Graphics::Print без переписывания команд.
// ---------------------------------------------------------------------

static void PrintLn(const CHAR16* s) {
    Console::Print(s);
    Console::Print(u"\r\n");
}

static void Print(const CHAR16* s) {
    Console::Print(s);
}

static void PrintNum(uint64_t v) {
    CHAR16 buf[24];
    u64ToStr16(v, buf);
    Console::Print(buf);
}

static void PrintHex64(uint64_t v) {
    const CHAR16* digits = u"0123456789ABCDEF";
    CHAR16 buf[17];
    for (int i = 15; i >= 0; i--) { buf[i] = digits[v & 0xF]; v >>= 4; }
    buf[16] = 0;
    Console::Print(buf);
}

static void PrintError(const CHAR16* msg) {
    Console::SetAttribute(kAttrError);
    PrintLn(msg);
    Console::SetAttribute(kAttrNormal);
}

// ---------------------------------------------------------------------
// Чтение строки с клавиатуры (посимвольно, с поддержкой Backspace)
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// История команд (Up/Down в основной консоли — не в edit/fm-подсказках,
// см. параметр enableHistory ниже).
// ---------------------------------------------------------------------

static constexpr int kHistoryCap = 16;
static CHAR16 gHistory[kHistoryCap][kMaxLine];
static int gHistoryCount = 0;

static void HistoryPush(const CHAR16* line) {
    if (strlen16(line) == 0) return;
    if (gHistoryCount > 0 && stricmp16(gHistory[gHistoryCount - 1], line) == 0) return; // не дублируем подряд
    if (gHistoryCount < kHistoryCap) {
        strcpy16(gHistory[gHistoryCount++], line);
    } else {
        for (int i = 1; i < kHistoryCap; i++) strcpy16(gHistory[i - 1], gHistory[i]);
        strcpy16(gHistory[kHistoryCap - 1], line);
    }
}

// ---------------------------------------------------------------------
// Чтение строки с клавиатуры (посимвольно, с поддержкой Backspace и,
// опционально, истории команд по Up/Down).
// ---------------------------------------------------------------------

static int ReadLine(CHAR16* buf, int maxLen, bool enableHistory = false) {
    int len = 0;
    buf[0] = 0;
    int histIndex = gHistoryCount; // "за пределами последней" = пустая строка

    for (;;) {
        CHAR16 c = Keyboard::GetKey(); // блокирующее чтение

        if (c == Keys::CarriageReturn || c == Keys::Linefeed) {
            buf[len] = 0;
            PrintLn(u"");
            if (enableHistory) HistoryPush(buf);
            return len;
        }
        if (c == Keys::Backspace) {
            if (len > 0) {
                len--;
                // визуально стираем последний символ
                Print(u"\b \b");
            }
            continue;
        }
        if (enableHistory && (c == kKeyUp || c == kKeyDown)) {
            for (int i = 0; i < len; i++) Print(u"\b \b"); // стереть видимую строку
            if (c == kKeyUp) { if (histIndex > 0) histIndex--; }
            else            { if (histIndex < gHistoryCount) histIndex++; }
            if (histIndex < gHistoryCount) strcpy16(buf, gHistory[histIndex]);
            else buf[0] = 0;
            len = (int)strlen16(buf);
            Print(buf);
            continue;
        }
        // игнорируем прочие управляющие коды (не Up/Down)
        if (c >= 0x0100) continue;

        if (len < maxLen - 1) {
            buf[len++] = c;
            buf[len] = 0;
            CHAR16 echo[2] = { c, 0 };
            Print(echo);
        }
    }
}

// ---------------------------------------------------------------------
// Встроенные команды
// ---------------------------------------------------------------------

// forward-декларации: реализация ниже, рядом с HasImageExtension —
// используются и в консольной команде "run", и в автозапуске по
// голому имени файла в Dispatch().
static bool ResolveProgramPath(const CHAR16* nameIn, CHAR16* out, int outCap);
static void RunProgramPath(const CHAR16* path);
static bool IsUnsafeToReadAsText(const CHAR16* name);

static void CmdHelp(int argc, CHAR16** argv) {
    PrintLn(u"PS DOS - built-in commands (DOS / Unix hybrid syntax):");
    PrintLn(u"  dir, ls           - list files in current directory");
    PrintLn(u"  cd <path>         - change directory (cd .. goes up)");
    PrintLn(u"  type, cat <file>  - print file content");
    PrintLn(u"  del, rm <file>    - delete file");
    PrintLn(u"  copy, cp <a> <b>  - copy file");
    PrintLn(u"  move, mv <a> <b>  - move/rename file");
    PrintLn(u"  md, mkdir <name>  - create directory");
    PrintLn(u"  rd, rmdir <name>  - delete directory");
    PrintLn(u"  cls, clear        - clear screen");
    PrintLn(u"  pwd               - print current path");
    PrintLn(u"  disks             - list disks");
    PrintLn(u"  fm                - built-in file manager");
    PrintLn(u"  run <file>        - launch a .pex program");
    PrintLn(u"  <name>            - typing a program name runs it (like DOS)");
    PrintLn(u"  new <file>        - create an empty file");
    PrintLn(u"  edit <file>       - simple line editor (':wq' saves, ':q' cancels)");
    PrintLn(u"  ver               - PS DOS / kernel build info");
    PrintLn(u"  size <file>       - show real file size on disk (bytes)");
    PrintLn(u"  exit              - quit the shell");
    PrintLn(u"  Up/Down at the prompt - browse command history");
}

static void CmdVer(int argc, CHAR16** argv) {
    Print(u"PS DOS beta on ParrotOS kernel, build ");
    PrintNum(System::GetBuild());
    Print(u", version ");
    PrintNum(System::GetVersion());
    PrintLn(u"");
}

// Диагностическая команда: реальный размер файла на диске (в байтах),
// напрямую через INT 0x23/0x06 — чтобы видеть, действительно ли запись
// (edit/:wq, new) доходит до диска, а не только "Saved." на экране.
static void CmdSize(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: size <file>"); return; }
    uint64_t sz = 0;
    uint64_t r = FileSystem::GetFileSize(argv[1], &sz);
    if (r != 0) { PrintError(u"Could not get file size."); return; }
    Print(argv[1]);
    Print(u": ");
    PrintNum(sz);
    PrintLn(u" bytes");
}

// ВРЕМЕННО (диагностика): дёргает INT 0x23 / 0x99 — тестовый обработчик в
// ядре, который просто кладёт 0x1111/0x2222/0x3333 в RAX/RDX/R8, без
// единого вызова ФС. Если тут тоже придёт мусор — проблема в восстановлении
// регистров самим прерыванием, а не в FAT32_ReadFile. Уберите вместе с
// case 0x99 в ParrotOS.c после диагностики.
static void CmdRegTest(int argc, CHAR16** argv) {
    uint64_t a = 0, d = 0, r8 = 0;
    asm volatile (
        "movq $0x99, %%rax\n\t"
        "int $0x23\n\t"
        "movq %%rax, %0\n\t"
        "movq %%rdx, %1\n\t"
        "movq %%r8, %2"
        : "=r"(a), "=r"(d), "=r"(r8)
        :
        : "rax", "rdx", "r8"
    );
    Print(u"rax=0x"); PrintHex64(a);
    Print(u" rdx=0x"); PrintHex64(d);
    Print(u" r8=0x"); PrintHex64(r8);
    PrintLn(u"");
    Print(u"expected: rax=0x0000000000001111 rdx=0x0000000000002222 r8=0x0000000000003333");
    PrintLn(u"");
}

// ВРЕМЕННО (диагностика): дёргает INT 0x23 / 0x98 — тест "голого"
// Open+Read(64-байтный буфер на стеке)+Close, без GetInfo и без
// AllocatePool. rax=статус Read(), rdx=сколько байт реально прочитано,
// r8=первые 4 байта содержимого файла. Уберите вместе с case 0x98 в
// ParrotOS.c после диагностики.
static void CmdReadRawTest(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: readraw <file>"); return; }
    uint64_t a = 0, d = 0, r8 = 0;
    asm volatile (
        "movq $0x98, %%rax\n\t"
        "movq %3, %%rcx\n\t"
        "int $0x23\n\t"
        "movq %%rax, %0\n\t"
        "movq %%rdx, %1\n\t"
        "movq %%r8, %2"
        : "=r"(a), "=r"(d), "=r"(r8)
        : "r"(argv[1])
        : "rax", "rcx", "rdx", "r8"
    );
    Print(u"status=0x"); PrintHex64(a);
    Print(u" bytes_read="); PrintNum(d);
    Print(u" first4bytes=0x"); PrintHex64(r8);
    PrintLn(u"");
}

static void CmdCls(int argc, CHAR16** argv) {
    Console::Clear();
}

static void CmdPwd(int argc, CHAR16** argv) {
    PrintLn(FileSystem::GetCurrentPath());
}

static void CmdDisks(int argc, CHAR16** argv) {
    CHAR16* disks = FileSystem::ListDisks();
    if (disks) PrintLn(disks);
    else PrintError(u"Could not get disk list.");
}

static void CmdDir(int argc, CHAR16** argv) {
    CHAR16 path[kMaxLine];
    if (argc > 1) strcpy16(path, argv[1]);
    else strcpy16(path, u".");

    CHAR16* listing = FileSystem::ListDir(path);
    if (listing) {
        PrintLn(listing);
    } else {
        PrintError(u"Directory not found or empty.");
    }
}

static void CmdCd(int argc, CHAR16** argv) {
    if (argc < 2) {
        PrintLn(FileSystem::GetCurrentPath());
        return;
    }
    if (stricmp16(argv[1], u"..") == 0) {
        FileSystem::PathUp();
        return;
    }
    uint64_t r = FixedChangeDir(argv[1]);
    if (r != 0) PrintError(u"Directory not found.");
}

static void CmdType(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: type <file>"); return; }
    if (IsUnsafeToReadAsText(argv[1])) {
        PrintError(u"Refusing to read this as text (looks like a binary file - reading binary files has crashed the system before).");
        return;
    }
    EC16 res;
    FileSystem::ReadFileByPath(argv[1], &res); // ReadFileByPath, не ReadFile —
    // см. комментарий у IsUnsafeToReadAsText ниже: ReadFile (случай 0x11,
    // структура по значению через два слоя вызовов) давала мусор в RAX/RDX/
    // R8 в тестах; ReadFileByPath пишет результат через явный указатель и
    // работает надёжно. Подтверждено на реальном железе/эмуляторе.
    if (res.Status != 0 || !res.Message) {
        // Диагностика: показываем СЫРЫЕ значения, которые реально вернул
        // INT 0x23/0x11 (rax=Status, rdx=Message-указатель, r8=FileSize) —
        // не мою интерпретацию. Status — это EFI_STATUS: если старший бит
        // 64-битного числа установлен (т.е. значение выглядит как
        // 0x80000000000000XX), это код ошибки; XX в конце — конкретная
        // причина по таблице EFI_STATUS (EDK2: 0xE=NOT_FOUND, 0xF=ACCESS_
        // DENIED, 0x5=BUFFER_TOO_SMALL, 0x1A=VOLUME_CORRUPTED и т.д.).
        Console::SetAttribute(kAttrError);
        Print(u"Could not read file. status=0x");
        PrintHex64(res.Status);
        Print(u" message=0x");
        PrintHex64((uint64_t)res.Message);
        Print(u" filesize=");
        PrintNum(res.FileSize);
        PrintLn(u"");
        Console::SetAttribute(kAttrNormal);
        return;
    }
    PrintLn(res.Message);
}

static void CmdDel(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: del <file>"); return; }
    uint64_t r = FileSystem::DeleteFile(argv[1]);
    if (r != 0) PrintError(u"Could not delete file.");
}

static void CmdCopy(int argc, CHAR16** argv) {
    if (argc < 3) { PrintError(u"Usage: copy <from> <to>"); return; }
    uint64_t r = FileSystem::CopyFile(argv[1], argv[2]);
    if (r != 0) PrintError(u"Could not copy file.");
}

static void CmdMove(int argc, CHAR16** argv) {
    if (argc < 3) { PrintError(u"Usage: move <from> <to>"); return; }
    uint64_t r = FileSystem::MoveFile(argv[1], argv[2]);
    if (r != 0) PrintError(u"Could not move file.");
}

static void CmdMkdir(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: md <name>"); return; }
    uint64_t r = FileSystem::CreateDir(argv[1]);
    if (r != 0) PrintError(u"Could not create directory.");
}

static void CmdRmdir(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: rd <name>"); return; }
    uint64_t r = FileSystem::DeleteDir(argv[1]);
    if (r != 0) PrintError(u"Could not delete directory.");
}

static void CmdEcho(int argc, CHAR16** argv) {
    for (int i = 1; i < argc; i++) {
        Print(argv[i]);
        if (i + 1 < argc) Print(u" ");
    }
    PrintLn(u"");
}

static void CmdRun(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: run <file>"); return; }
    CHAR16 path[kMaxLine];
    if (!ResolveProgramPath(argv[1], path, kMaxLine)) {
        PrintError(u"File not found.");
        return;
    }
    RunProgramPath(path);
}

static void CmdNew(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: new <file>"); return; }
    uint64_t r = FileSystem::CreateFile(argv[1]);
    if (r != 0) PrintError(u"Could not create file.");
}

// Простейший построчный редактор (не Vim, но рабочий): печатаете строки,
// они копятся в буфере; ":wq" на отдельной строке — сохранить и выйти,
// ":q" — выйти без сохранения. Лимит буфера — 8000 CHAR16 на файл в
// этой версии (полноценный постраничный редактор — отдельная задача).
static constexpr uint64_t kEditBufCap = 8000;

static void CmdEdit(int argc, CHAR16** argv) {
    if (argc < 2) { PrintError(u"Usage: edit <file>"); return; }

    PrintLn(u"--- simple line editor ---");
    PrintLn(u"Type lines. ':wq' on its own line saves & exits, ':q' cancels.");

    static CHAR16 content[kEditBufCap];
    uint64_t total = 0;
    CHAR16 line[kMaxLine];

    for (;;) {
        Print(u"| ");
        ReadLine(line, kMaxLine);

        if (stricmp16(line, u":wq") == 0) {
            uint64_t r = FileSystem::WriteFile(argv[1], (const uint16_t*)content, total);
            if (r != 0) PrintError(u"Could not save file.");
            else PrintLn(u"Saved.");
            return;
        }
        if (stricmp16(line, u":q") == 0) {
            PrintLn(u"Cancelled (not saved).");
            return;
        }

        uint64_t llen = strlen16(line);
        if (total + llen + 2 >= kEditBufCap) {
            PrintError(u"Buffer full (8000 chars max in this version) - save with ':wq' now.");
            continue;
        }
        for (uint64_t i = 0; i < llen; i++) content[total++] = line[i];
        content[total++] = u'\r';
        content[total++] = u'\n';
    }
}

// ---------------------------------------------------------------------
// Встроенный текстовый файловый менеджер (команда "fm")
//
// Первая версия: одна панель, список файлов текущего каталога,
// навигация стрелками вверх/вниз, Enter — зайти в каталог / открыть
// (type) файл, Esc — выход. Полноэкранным его не делаем — используем
// уже существующий текстовый режим консоли, без Graphics::*.
// ---------------------------------------------------------------------

static constexpr int kFmMaxEntries = 128;
static constexpr int kFmNameLen    = 64;

struct FmEntry {
    CHAR16 name[kFmNameLen];
    bool isDir;
};

// Разбирает ОДНУ строку вывода FileSystem::ListDir вида
// "<dir>   EFI" / "<file>  ico_100x100.bmp" — формат виден по выводу
// команды ls/dir (см. скриншот): тег типа + пробелы + имя.
// Возвращает false для строк, не подходящих под этот формат (пустые
// строки и т.п.) — их просто пропускаем.
static bool ParseListingLine(const CHAR16* line, int lineLen, FmEntry* out) {
    const CHAR16* p = line;
    const CHAR16* end = line + lineLen;
    bool isDir;

    auto startsWith = [&](const CHAR16* tag, int tagLen) {
        if (end - p < tagLen) return false;
        for (int i = 0; i < tagLen; i++) if (p[i] != tag[i]) return false;
        return true;
    };

    if (startsWith(u"<dir>", 5))       { isDir = true;  p += 5; }
    else if (startsWith(u"<file>", 6)) { isDir = false; p += 6; }
    else return false; // неизвестный формат строки — пропускаем

    while (p < end && isSpace16(*p)) p++;
    int i = 0;
    while (p < end && i < kFmNameLen - 1) out->name[i++] = *p++;
    out->name[i] = 0;
    if (i == 0) return false;
    out->isDir = isDir;
    return true;
}

// Раньше здесь была догадка про ANSI-последовательность ESC '[' A/B/C/D
// на случай, если драйвер шлёт стрелки так. Debug-строка в fm подтвердила
// реальную схему кодов (0xFF00 | id, см. kKeyUp/kKeyDown/... выше) — она
// приходит одним кодом, никакой ANSI-последовательности нет. Оставляем
// простое чтение; *outRaw нужен только для диагностической строки на
// экране fm.
static CHAR16 FmReadKey(CHAR16* outRaw) {
    CHAR16 key = Keyboard::GetKey();
    *outRaw = key;
    return key;
}

// Проверка расширения на "это картинка" — нет предпросмотра изображений
// (и вообще графики в fm), такие файлы не дампим как текст.
static bool HasImageExtension(const CHAR16* name) {
    return endsWithCI16(name, u".bmp") || endsWithCI16(name, u".png") ||
           endsWithCI16(name, u".jpg") || endsWithCI16(name, u".jpeg") ||
           endsWithCI16(name, u".ico");
}

// ВАЖНО (безопасность): FileSystem::ReadFile у нас в проекте несколько
// раз приводил к падению системы (BSOD, Page Fault) при попытке прочитать
// бинарный файл как текст (например system.ttf, NvVars) — судя по всему,
// внутри ядра чтение файла не рассчитано на произвольные бинарные данные
// (возможно ищет CHAR16-терминатор 0x0000, которого в бинарнике может не
// быть достаточно долго, и уезжает за пределы буфера). Раз крашится сама
// система, а не наш процесс — постфактум это не отловить, поэтому просто
// НЕ вызываем ReadFile для файлов, похожих на бинарные: по расширению
// (картинки, шрифты, исполняемые) и по отдельным известным именам без
// расширения (NvVars — бинарное хранилище EFI-переменных). Это эвристика,
// не гарантия: файл с "безопасным" на вид именем всё ещё может быть
// бинарным и уронить систему — если увидите это снова, пришлите имя
// файла, расширю список.
static bool IsUnsafeToReadAsText(const CHAR16* name) {
    if (HasImageExtension(name)) return true;
    if (endsWithCI16(name, u".ttf") || endsWithCI16(name, u".otf")) return true;
    if (endsWithCI16(name, u".pex") || endsWithCI16(name, u".bin") ||
        endsWithCI16(name, u".dat") || endsWithCI16(name, u".efi")) return true;
    if (stricmp16(name, u"NvVars") == 0) return true;
    return false;
}

// ---------------------------------------------------------------------
// Запуск .pex программ — команда "run", а также автозапуск, если в
// консоли набрано просто имя файла (DOS/CMD-стиль: "programname" без
// команды запускает его). Работает и с именем без расширения (тогда
// достраивается ".pex"), и с полным именем.
// ---------------------------------------------------------------------

static bool ResolveProgramPath(const CHAR16* nameIn, CHAR16* out, int outCap) {
    strcpy16(out, nameIn);
    if (FileSystem::FileExists(out)) return true;
    if (!endsWithCI16(out, u".pex")) {
        CHAR16 withExt[kMaxLine];
        strcpy16(withExt, nameIn);
        strcat16(withExt, u".pex");
        if (FileSystem::FileExists(withExt)) {
            strcpy16(out, withExt);
            return true;
        }
    }
    return false;
}

static void RunProgramPath(const CHAR16* path) {
    Process procInfo = {};
    procInfo.Name = path;
    procInfo.ArgContext = nullptr;
    uint64_t r = TaskManager::RunPex(path, &procInfo);
    if (r != 0) PrintError(u"Failed to run program.");
    TaskManager::Yield(); // дождаться завершения процесса (иначе вернёмся в fm/консоль, а процесс будет висеть в фоне)
}

// Мини-ввод строки внизу экрана — для rename/new прямо внутри fm, без
// выхода из менеджера. Возвращает false, если ввод пустой (отмена).
static bool FmPromptLine(const CHAR16* prompt, CHAR16* out, int cap) {
    Console::SetAttribute(kAttrPrompt);
    Print(prompt);
    Console::SetAttribute(kAttrNormal);
    ReadLine(out, cap);
    return strlen16(out) > 0;
}

static void RunFileManager() {
    CHAR16 lastRaw = 0; // для диагностической строки внизу экрана

    for (;;) { // "перезаход" после cd/rename/delete — цикл вместо рекурсии
        FmEntry entries[kFmMaxEntries];
        int count = 0;

        CHAR16* raw = FileSystem::ListDir((CHAR16*)u".");
        if (raw) {
            const CHAR16* lineStart = raw;
            for (const CHAR16* p = raw; ; p++) {
                if (*p == u'\n' || *p == u'\r' || *p == 0) {
                    int lineLen = (int)(p - lineStart);
                    if (lineLen > 0 && count < kFmMaxEntries) {
                        if (ParseListingLine(lineStart, lineLen, &entries[count])) count++;
                    }
                    if (*p == 0) break;
                    lineStart = p + 1;
                }
            }
        }

        int selected = 0;
        bool reload = false;
        bool exitFm = false;

        while (!reload && !exitFm) {
            Console::Clear();
            Console::SetAttribute(kAttrPrompt);
            PrintLn(u"=== PS DOS File Manager ===");
            Console::SetAttribute(kAttrNormal);
            Print(u"  ");
            PrintLn(FileSystem::GetCurrentPath());
            Console::SetAttribute(0x08); // тёмно-серый — подсказка по клавишам
            PrintLn(u"  Up/Down or W/S: move   Enter: open   Backspace/U: up-dir");
            PrintLn(u"  R: rename   D: delete   N: new file   Q/Esc: quit");
            Console::SetAttribute(kAttrNormal);
            PrintLn(u"");

            if (count == 0) {
                Console::SetAttribute(0x08);
                PrintLn(u"  (empty, or listing format not recognized)");
                Console::SetAttribute(kAttrNormal);
            }

            for (int i = 0; i < count; i++) {
                if (i == selected) Console::SetAttribute(0x70); // инверсия
                else Console::SetAttribute(kAttrNormal);
                Print(u"  ");
                Print(entries[i].isDir ? u"[DIR] " : u"[   ] ");
                PrintLn(entries[i].name);
            }
            Console::SetAttribute(kAttrNormal);

            // Диагностическая строка — код последней нераспознанной клавиши.
            // Уберите этот блок, когда стрелки/Esc будут подтверждены как
            // рабочие; буквенные хоткеи (W/S/Enter/Backspace/Q/R/D/N) не
            // зависят от этого и работают всегда.
            Console::SetAttribute(0x08);
            Print(u"  [debug] last raw key = 0x");
            CHAR16 hex[5] = {
                u"0123456789ABCDEF"[(lastRaw >> 12) & 0xF],
                u"0123456789ABCDEF"[(lastRaw >> 8) & 0xF],
                u"0123456789ABCDEF"[(lastRaw >> 4) & 0xF],
                u"0123456789ABCDEF"[lastRaw & 0xF],
                0
            };
            PrintLn(hex);
            Console::SetAttribute(kAttrNormal);

            CHAR16 rawKey = 0;
            CHAR16 key = FmReadKey(&rawKey);
            lastRaw = rawKey;

            // буквы — регистронезависимо, работают ВСЕГДА, независимо от
            // того, распознаются ли стрелки/Esc на этом драйвере клавиатуры
            CHAR16 lower = toLower16(key);

            if (key == kKeyUp || lower == u'w') {
                if (selected > 0) selected--;
            } else if (key == kKeyDown || lower == u's') {
                if (count > 0 && selected < count - 1) selected++;
            } else if (key == kKeyEsc || key == 0x001B || lower == u'q') {
                exitFm = true;
            } else if (key == Keys::Backspace || lower == u'u' || key == kKeyLeft) {
                FileSystem::PathUp();
                reload = true;
            } else if (lower == u'n') {
                CHAR16 name[kFmNameLen];
                if (FmPromptLine(u"  New file name: ", name, kFmNameLen)) {
                    uint64_t r = FileSystem::CreateFile(name);
                    if (r != 0) { PrintError(u"Could not create file."); PrintLn(u"--- press any key ---"); Keyboard::GetKey(); }
                }
                reload = true;
            } else if (lower == u'r' && count > 0) {
                FmEntry& sel = entries[selected];
                CHAR16 newName[kFmNameLen];
                CHAR16 prompt[kFmNameLen + 16];
                strcpy16(prompt, u"  Rename '");
                strcat16(prompt, sel.name);
                strcat16(prompt, u"' to: ");
                if (FmPromptLine(prompt, newName, kFmNameLen)) {
                    uint64_t r = FileSystem::MoveFile(sel.name, newName);
                    if (r != 0) { PrintError(u"Could not rename."); PrintLn(u"--- press any key ---"); Keyboard::GetKey(); }
                }
                reload = true;
            } else if (lower == u'd' && count > 0) {
                FmEntry& sel = entries[selected];
                Console::SetAttribute(kAttrError);
                Print(u"  Delete '");
                Print(sel.name);
                Print(u"'? (y/n) ");
                Console::SetAttribute(kAttrNormal);
                CHAR16 confirm = Keyboard::GetKey();
                if (toLower16(confirm) == u'y') {
                    uint64_t r = sel.isDir ? FileSystem::DeleteDir(sel.name)
                                            : FileSystem::DeleteFile(sel.name);
                    if (r != 0) { PrintError(u"Could not delete."); PrintLn(u"--- press any key ---"); Keyboard::GetKey(); }
                }
                reload = true;
            } else if ((key == Keys::CarriageReturn || key == Keys::Linefeed) && count > 0) {
                FmEntry& sel = entries[selected];
                if (sel.isDir) {
                    if (stricmp16(sel.name, u"..") == 0) FileSystem::PathUp();
                    else FixedChangeDir(sel.name);
                    reload = true;
                } else if (endsWithCI16(sel.name, u".pex")) {
                    RunProgramPath(sel.name);
                } else if (HasImageExtension(sel.name)) {
                    Console::Clear();
                    PrintError(u"Image preview is not implemented yet.");
                    PrintLn(u"--- press any key ---");
                    Keyboard::GetKey();
                } else if (IsUnsafeToReadAsText(sel.name)) {
                    Console::Clear();
                    PrintError(u"Refusing to open - looks like a binary file (has crashed the system before).");
                    PrintLn(u"--- press any key ---");
                    Keyboard::GetKey();
                } else {
                    EC16 res;
                    FileSystem::ReadFileByPath(sel.name, &res); // см. CmdType — ReadFileByPath надёжнее ReadFile
                    Console::Clear();
                    if (res.Status == 0 && res.Message) PrintLn(res.Message);
                    else PrintError(u"Could not open file.");
                    PrintLn(u"--- press any key ---");
                    Keyboard::GetKey();
                }
            }
        }

        if (exitFm) return;
        // reload == true: внешний for(;;) перечитает каталог с уже
        // обновлённым текущим путём (FileSystem::GetCurrentPath())
    }
}

static void CmdFm(int argc, CHAR16** argv) {
    RunFileManager();
}

static void CmdExit(int argc, CHAR16** argv) {
    TaskManager::Exit();
}

// ---------------------------------------------------------------------
// Таблица команд: имя -> обработчик. Алиасы DOS и Unix указывают на
// одну и ту же функцию — в этом суть "гибридного" синтаксиса PS DOS.
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// Диспетчер команд.
//
// ВАЖНО: раньше здесь была статическая таблица { CHAR16* name; funcptr }.
// Она не работала — диагностика показала, что все указатели в ней
// разыменовывались в пустую строку. Причина: это плоский .pex без
// поддержки релокаций у загрузчика. Строка/функция, на которую вы
// ссылаетесь ПРЯМО В КОДЕ (Print(u"..."), вызов CmdDir(...) и т.п.),
// адресуется компилятором через RIP-relative инструкции (lea/call) —
// это самокорректируется независимо от того, по какому адресу
// загрузчик реально разместил процесс в памяти. А адрес, заранее
// "зашитый" как ЗНАЧЕНИЕ в глобальные данные (наша таблица), линковщик
// вычисляет в расчёте на загрузку по адресу 0x0 — и если загрузчик
// кладёт процесс не туда (а он явно не туда), значение неверное.
// Функция-обработчик из той же таблицы страдала бы точно так же.
//
// Поэтому здесь — обычная цепочка if/else, где и сравнение, и вызов
// идут прямо в коде. Алиасы DOS/Unix — просто дополнительные if на ту
// же функцию.
// ---------------------------------------------------------------------

static void Dispatch(int argc, CHAR16** argv) {
    if (argc == 0) return;
    const CHAR16* c = argv[0];

    if (stricmp16(c, u"dir") == 0 || stricmp16(c, u"ls") == 0) CmdDir(argc, argv);
    else if (stricmp16(c, u"cd") == 0) CmdCd(argc, argv);
    else if (stricmp16(c, u"type") == 0 || stricmp16(c, u"cat") == 0) CmdType(argc, argv);
    else if (stricmp16(c, u"del") == 0 || stricmp16(c, u"rm") == 0) CmdDel(argc, argv);
    else if (stricmp16(c, u"copy") == 0 || stricmp16(c, u"cp") == 0) CmdCopy(argc, argv);
    else if (stricmp16(c, u"move") == 0 || stricmp16(c, u"mv") == 0) CmdMove(argc, argv);
    else if (stricmp16(c, u"md") == 0 || stricmp16(c, u"mkdir") == 0) CmdMkdir(argc, argv);
    else if (stricmp16(c, u"rd") == 0 || stricmp16(c, u"rmdir") == 0) CmdRmdir(argc, argv);
    else if (stricmp16(c, u"cls") == 0 || stricmp16(c, u"clear") == 0) CmdCls(argc, argv);
    else if (stricmp16(c, u"pwd") == 0) CmdPwd(argc, argv);
    else if (stricmp16(c, u"disks") == 0) CmdDisks(argc, argv);
    else if (stricmp16(c, u"echo") == 0) CmdEcho(argc, argv);
    else if (stricmp16(c, u"fm") == 0) CmdFm(argc, argv);
    else if (stricmp16(c, u"run") == 0) CmdRun(argc, argv);
    else if (stricmp16(c, u"new") == 0) CmdNew(argc, argv);
    else if (stricmp16(c, u"edit") == 0) CmdEdit(argc, argv);
    else if (stricmp16(c, u"ver") == 0) CmdVer(argc, argv);
    else if (stricmp16(c, u"size") == 0) CmdSize(argc, argv);
    else if (stricmp16(c, u"regtest") == 0) CmdRegTest(argc, argv);
    else if (stricmp16(c, u"readraw") == 0) CmdReadRawTest(argc, argv);
    else if (stricmp16(c, u"help") == 0 || stricmp16(c, u"?") == 0) CmdHelp(argc, argv);
    else if (stricmp16(c, u"exit") == 0 || stricmp16(c, u"quit") == 0) CmdExit(argc, argv);
    else {
        // DOS/CMD-стиль: если строка совпадает с именем существующего
        // файла (с ".pex" или без) — запускаем его как программу, а не
        // сразу ругаемся на неизвестную команду.
        CHAR16 path[kMaxLine];
        if (ResolveProgramPath(c, path, kMaxLine)) {
            RunProgramPath(path);
        } else {
            PrintError(u"Unknown command. Type 'help' for a list."); // временно на английском — кириллица не рендерится
        }
    }
}

// ---------------------------------------------------------------------
// Разбор аргументов запуска процесса — см. предупреждение в шапке файла:
// формат ArgContext для .pex пока не задокументирован в ядре, поэтому
// парсинг защитный (не находит "-gfx" -> остаёмся в текстовом режиме).
// TODO: заменить на реальный разбор, когда формат ArgContext будет
// зафиксирован (сейчас всем приложениям должен передаваться единый
// аргумент режима — задача ядра/пред-загрузчика, не этого файла).
// ---------------------------------------------------------------------

static void ParseLaunchArgs(struct Process* pr) {
    gGfxMode = false;
    if (!pr || !pr->ArgContext) return;
    const CHAR16* args = (const CHAR16*)pr->ArgContext;
    // ищем подстроку "-gfx" простым посимвольным поиском
    for (const CHAR16* p = args; *p; p++) {
        if (p[0]==u'-' && p[1]==u'g' && p[2]==u'f' && p[3]==u'x') {
            gGfxMode = true;
            break;
        }
    }
}

// ---------------------------------------------------------------------
// Точка входа
// ---------------------------------------------------------------------

void main(struct Process* pr) {
    ParseLaunchArgs(pr);

    Console::Clear();
    Console::SetAttribute(kAttrPrompt);
    PrintLn(u"PS DOS [Version 0.1 beta / ParrotOS kernel beta-3]");
    Console::SetAttribute(kAttrNormal);
    PrintLn(u"Type 'help' for a list of commands.");
    PrintLn(u"");

    // TODO: графический режим — если gGfxMode == true, переключить
    // Print/PrintLn/ReadLine на Graphics::Print + отрисовку курсора
    // вручную (Graphics:: не имеет построчного консольного вывода,
    // поэтому потребуется отдельный слой "виртуального терминала"
    // поверх фреймбуфера — вынесено в отдельную задачу).

    CHAR16 line[kMaxLine];
    CHAR16* argv[kMaxArgs];

    for (;;) {
        Console::SetAttribute(kAttrPrompt);
        Print(FileSystem::GetCurrentPath());
        Print(u"> ");
        Console::SetAttribute(kAttrNormal);

        ReadLine(line, kMaxLine, /*enableHistory=*/true);
        int argc = tokenize16(line, argv, kMaxArgs);
        Dispatch(argc, argv);
    }
}