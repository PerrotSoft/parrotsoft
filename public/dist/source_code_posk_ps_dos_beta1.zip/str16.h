// str16.h — минимальный набор функций для работы с CHAR16-строками.
// Окружение freestanding (нет libc), поэтому всё пишем сами.
#pragma once
#include "ParrotOS_API.hpp"

namespace ps {

using CHAR16 = char16_t; // определён глобально в ParrotOS_API.hpp

inline uint64_t strlen16(const CHAR16* s) {
    uint64_t n = 0;
    while (s[n] != 0) n++;
    return n;
}

inline int strcmp16(const CHAR16* a, const CHAR16* b) {
    while (*a && (*a == *b)) { a++; b++; }
    return (int)*a - (int)*b;
}

// Регистронезависимое сравнение — команды в PS DOS нечувствительны к регистру,
// как в MS-DOS.
inline CHAR16 toLower16(CHAR16 c) {
    if (c >= u'A' && c <= u'Z') return c + (u'a' - u'A');
    return c;
}

inline int stricmp16(const CHAR16* a, const CHAR16* b) {
    while (*a && (toLower16(*a) == toLower16(*b))) { a++; b++; }
    return (int)toLower16(*a) - (int)toLower16(*b);
}

inline void strcpy16(CHAR16* dst, const CHAR16* src) {
    while ((*dst++ = *src++));
}

inline void strcat16(CHAR16* dst, const CHAR16* src) {
    while (*dst) dst++;
    strcpy16(dst, src);
}

inline bool isSpace16(CHAR16 c) {
    return c == u' ' || c == u'\t';
}

// Разбивает строку command line на токены "на месте" (заменяет пробелы на \0).
// Возвращает количество токенов, заполняет argv (максимум maxArgs).
inline int tokenize16(CHAR16* line, CHAR16** argv, int maxArgs) {
    int argc = 0;
    CHAR16* p = line;
    while (*p && argc < maxArgs) {
        while (isSpace16(*p)) *p++ = 0;
        if (!*p) break;
        argv[argc++] = p;
        while (*p && !isSpace16(*p)) p++;
    }
    if (*p) *p = 0; // на случай если maxArgs исчерпан
    return argc;
}

// Простейшая конвертация целого в CHAR16-строку (десятичная, без знака minus
// для простоты — размеры файлов и т.п. всегда >= 0).
inline void u64ToStr16(uint64_t v, CHAR16* out) {
    CHAR16 buf[24];
    int i = 0;
    if (v == 0) { out[0] = u'0'; out[1] = 0; return; }
    while (v > 0 && i < 23) { buf[i++] = u'0' + (CHAR16)(v % 10); v /= 10; }
    int j = 0;
    while (i > 0) out[j++] = buf[--i];
    out[j] = 0;
}

inline bool endsWithCI16(const CHAR16* name, const CHAR16* suffix) {
    uint64_t nameLen = strlen16(name);
    uint64_t sufLen = strlen16(suffix);
    if (nameLen < sufLen) return false;
    for (uint64_t i = 0; i < sufLen; i++) {
        if (toLower16(name[nameLen - sufLen + i]) != toLower16(suffix[i])) return false;
    }
    return true;
}

} // namespace ps